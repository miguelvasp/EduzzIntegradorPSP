import type { PspType } from '../../../../shared/domain/enums/pspType';
import {
  getSqlRequest,
  sql,
} from '../../../../shared/infrastructure/persistence/SqlServerConnection';
import type {
  SyncCheckpoint,
  SyncCheckpointRepository,
} from '../../../application/ports/SyncCheckpointRepository';

type SyncCheckpointRow = {
  psp: PspType;
  checkpoint_value: string;
  last_sync_at: Date | null;
  page: number | null;
  offset: number | null;
  updated_at: Date;
};

export class SqlServerSyncCheckpointRepository implements SyncCheckpointRepository {
  public async getByPsp(psp: PspType): Promise<SyncCheckpoint | null> {
    const request = await getSqlRequest();

    const result = await request.input('psp', sql.NVarChar(30), psp).query<SyncCheckpointRow>(`
        SELECT TOP (1)
          psp,
          checkpoint_value,
          last_sync_at,
          page,
          offset,
          updated_at
        FROM dbo.sync_checkpoints
        WHERE psp = @psp
      `);

    const row = result.recordset[0];

    if (!row) {
      return null;
    }

    const checkpointValue = row.checkpoint_value;
    const parsedCursor =
      checkpointValue.startsWith('page:') || checkpointValue.startsWith('offset:')
        ? undefined
        : checkpointValue;

    return {
      psp: row.psp,
      checkpointValue,
      lastSyncAt: row.last_sync_at ?? undefined,
      page: row.page ?? undefined,
      offset: row.offset ?? undefined,
      cursor: parsedCursor,
      updatedAt: row.updated_at,
    };
  }

  public async save(checkpoint: SyncCheckpoint): Promise<void> {
    const request = await getSqlRequest();

    await request
      .input('psp', sql.NVarChar(30), checkpoint.psp)
      .input('checkpointValue', sql.NVarChar(200), checkpoint.checkpointValue)
      .input('lastSyncAt', sql.DateTime2, checkpoint.lastSyncAt ?? null)
      .input('page', sql.Int, checkpoint.page ?? null)
      .input('offset', sql.Int, checkpoint.offset ?? null)
      .input('updatedAt', sql.DateTime2, checkpoint.updatedAt).query(`
        MERGE dbo.sync_checkpoints AS target
        USING (
          SELECT
            @psp AS psp,
            @checkpointValue AS checkpoint_value,
            @lastSyncAt AS last_sync_at,
            @page AS page,
            @offset AS offset,
            @updatedAt AS updated_at
        ) AS source
        ON target.psp = source.psp
        WHEN MATCHED THEN
          UPDATE SET
            checkpoint_value = source.checkpoint_value,
            last_sync_at = source.last_sync_at,
            page = source.page,
            offset = source.offset,
            updated_at = source.updated_at
        WHEN NOT MATCHED THEN
          INSERT
          (
            psp,
            checkpoint_value,
            last_sync_at,
            page,
            offset,
            updated_at
          )
          VALUES
          (
            source.psp,
            source.checkpoint_value,
            source.last_sync_at,
            source.page,
            source.offset,
            source.updated_at
          );
      `);
  }
}
