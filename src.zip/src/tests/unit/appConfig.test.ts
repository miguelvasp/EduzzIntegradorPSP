import { readFileSync } from 'node:fs';
import { readdirSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

import { createConfiguration } from '../../app/config/configuration';
import { formatValidationErrors, validateEnvironment } from '../../app/config/validation';

function buildEnvironment(overrides: Record<string, string | undefined> = {}): Record<string, string | undefined> {
  return {
    APP_NAME: 'eduzz-integrador-psp',
    NODE_ENV: 'production',
    HOST: '127.0.0.1',
    PORT: '8080',
    LOG_LEVEL: 'debug',
    DOCS_ENABLED: 'false',
    DATABASE_HOST: 'db.internal',
    DATABASE_PORT: '1444',
    DATABASE_NAME: 'eduzz_multi_psp',
    DATABASE_USER: 'integration_user',
    DATABASE_PASSWORD: 'masked-password',
    DATABASE_CONNECTION_TIMEOUT_MS: '6000',
    DATABASE_POOL_MIN: '2',
    DATABASE_POOL_MAX: '8',
    PSP_USE_MOCK_SERVER: 'false',
    PSP_TIMEOUT_MS: '15000',
    PSP_RETRY_ATTEMPTS: '4',
    PAGARME_BASE_URL: 'https://pagarme.example.com',
    PAGARME_API_KEY: 'token-placeholder',
    MERCADOPAGO_BASE_URL: 'https://mercadopago.example.com',
    MERCADOPAGO_ACCESS_TOKEN: 'access-token-placeholder',
    SYNC_PAGE_SIZE: '30',
    SYNC_MAX_PAGE_SIZE: '120',
    SYNC_INCREMENTAL_WINDOW_MINUTES: '90',
    SYNC_SAFETY_OVERLAP_MINUTES: '10',
    SECURITY_HASH_SALT: 'hash-salt-placeholder',
    SECURITY_MASK_SENSITIVE_DATA: 'false',
    SECURITY_REDACT_SECRETS_IN_LOGS: 'true',
    OBS_STRUCTURED_LOGGING: 'true',
    OBS_METRICS_ENABLED: 'true',
    OBS_REQUEST_CORRELATION_ENABLED: 'false',
    CACHE_ENABLED: 'true',
    CACHE_TTL_SECONDS: '300',
    OUTBOX_DISPATCHER_ENABLED: 'true',
    OUTBOX_BATCH_SIZE: '75',
    OUTBOX_POLL_INTERVAL_MS: '8000',
    OUTBOX_RETRY_LIMIT: '5',
    ...overrides,
  };
}

function listTypeScriptFiles(directory: string): string[] {
  return readdirSync(directory).flatMap((entry) => {
    const entryPath = join(directory, entry);
    const entryStat = statSync(entryPath);

    if (entryStat.isDirectory()) {
      if (entry === 'tests' || entry === 'dist' || entry === 'node_modules') {
        return [];
      }

      return listTypeScriptFiles(entryPath);
    }

    return entryPath.endsWith('.ts') ? [entryPath] : [];
  });
}

describe('application configuration', () => {
  it('should build the final grouped configuration from valid inputs', () => {
    const environment = validateEnvironment(buildEnvironment());
    const config = createConfiguration(environment);

    expect(config).toEqual({
      app: {
        name: 'eduzz-integrador-psp',
        env: 'production',
        host: '127.0.0.1',
        port: 8080,
        logLevel: 'debug',
        docsEnabled: false,
        isDevelopment: false,
        isTest: false,
        isProduction: true,
      },
      database: {
        host: 'db.internal',
        port: 1444,
        name: 'eduzz_multi_psp',
        user: 'integration_user',
        password: 'masked-password',
        connectionTimeoutMs: 6000,
        poolMin: 2,
        poolMax: 8,
      },
      psp: {
        useMockServer: false,
        timeoutMs: 15000,
        retryAttempts: 4,
        pagarme: {
          baseUrl: 'https://pagarme.example.com',
          apiKey: 'token-placeholder',
        },
        mercadopago: {
          baseUrl: 'https://mercadopago.example.com',
          accessToken: 'access-token-placeholder',
        },
      },
      sync: {
        pageSize: 30,
        maxPageSize: 120,
        incrementalWindowMinutes: 90,
        safetyOverlapMinutes: 10,
      },
      security: {
        hashSalt: 'hash-salt-placeholder',
        maskSensitiveData: false,
        redactSecretsInLogs: true,
      },
      observability: {
        structuredLogging: true,
        metricsEnabled: true,
        requestCorrelationEnabled: false,
      },
      cache: {
        enabled: true,
        ttlSeconds: 300,
      },
      outbox: {
        dispatcherEnabled: true,
        batchSize: 75,
        pollIntervalMs: 8000,
        retryLimit: 5,
      },
    });
  });

  it('should apply defaults when values are not provided', () => {
    const environment = validateEnvironment({});
    const config = createConfiguration(environment);

    expect(config.app).toEqual({
      name: 'eduzz-integrador-psp',
      env: 'development',
      host: '0.0.0.0',
      port: 3000,
      logLevel: 'info',
      docsEnabled: true,
      isDevelopment: true,
      isTest: false,
      isProduction: false,
    });
    expect(config.database).toEqual({
      host: 'localhost',
      port: 1433,
      name: 'eduzz_integrador_psp',
      user: 'sa',
      password: undefined,
      connectionTimeoutMs: 5000,
      poolMin: 1,
      poolMax: 10,
    });
    expect(config.psp).toEqual({
      useMockServer: true,
      timeoutMs: 10000,
      retryAttempts: 2,
      pagarme: {
        baseUrl: 'http://localhost:4010/pagarme',
        apiKey: undefined,
      },
      mercadopago: {
        baseUrl: 'http://localhost:4020/mercadopago',
        accessToken: undefined,
      },
    });
    expect(config.sync).toEqual({
      pageSize: 20,
      maxPageSize: 100,
      incrementalWindowMinutes: 60,
      safetyOverlapMinutes: 5,
    });
    expect(config.observability).toEqual({
      structuredLogging: true,
      metricsEnabled: false,
      requestCorrelationEnabled: true,
    });
    expect(config.cache).toEqual({
      enabled: false,
      ttlSeconds: 60,
    });
    expect(config.outbox).toEqual({
      dispatcherEnabled: false,
      batchSize: 50,
      pollIntervalMs: 5000,
      retryLimit: 3,
    });
  });

  it('should reject invalid formats and invariants', () => {
    expect(() => validateEnvironment(buildEnvironment({ PORT: '0' }))).toThrow();
    expect(() => validateEnvironment(buildEnvironment({ NODE_ENV: 'staging' }))).toThrow();
    expect(() => validateEnvironment(buildEnvironment({ PSP_TIMEOUT_MS: 'abc' }))).toThrow();
    expect(() => validateEnvironment(buildEnvironment({ DATABASE_POOL_MIN: '5', DATABASE_POOL_MAX: '4' }))).toThrow(
      'DATABASE_POOL_MAX must be greater than or equal to DATABASE_POOL_MIN',
    );
    expect(() => validateEnvironment(buildEnvironment({ SYNC_PAGE_SIZE: '50', SYNC_MAX_PAGE_SIZE: '20' }))).toThrow(
      'SYNC_MAX_PAGE_SIZE must be greater than or equal to SYNC_PAGE_SIZE',
    );
  });

  it('should parse accepted boolean values into the final configuration', () => {
    const environment = validateEnvironment(
      buildEnvironment({
        DOCS_ENABLED: 'off',
        PSP_USE_MOCK_SERVER: '1',
        SECURITY_MASK_SENSITIVE_DATA: 'no',
        OBS_METRICS_ENABLED: 'yes',
        CACHE_ENABLED: 'false',
        OUTBOX_DISPATCHER_ENABLED: 'on',
      }),
    );
    const config = createConfiguration(environment);

    expect(config.app.docsEnabled).toBe(false);
    expect(config.psp.useMockServer).toBe(true);
    expect(config.security.maskSensitiveData).toBe(false);
    expect(config.observability.metricsEnabled).toBe(true);
    expect(config.cache.enabled).toBe(false);
    expect(config.outbox.dispatcherEnabled).toBe(true);
  });

  it('should format validation errors with field names', () => {
    try {
      validateEnvironment(buildEnvironment({ PORT: '-1', NODE_ENV: 'staging' }));
    } catch (error) {
      expect(formatValidationErrors(error)).toContain('NODE_ENV');
      expect(formatValidationErrors(error)).toContain('PORT');
    }

    try {
      validateEnvironment(buildEnvironment({ DATABASE_POOL_MIN: '8', DATABASE_POOL_MAX: '2' }));
    } catch (error) {
      expect(formatValidationErrors(error)).toContain('DATABASE_POOL_MAX');
    }
  });

  it('should prevent direct process.env access outside the configuration layer', () => {
    const sourceRoot = resolve(process.cwd(), 'src');
    const allowedFile = resolve(process.cwd(), 'src/app/config/env.ts');
    const sourceFiles = listTypeScriptFiles(sourceRoot);

    const filesWithDirectEnvironmentAccess = sourceFiles.filter((filePath) => {
      if (resolve(filePath) === allowedFile) {
        return false;
      }

      return readFileSync(filePath, 'utf8').includes('process.env');
    });

    expect(filesWithDirectEnvironmentAccess).toEqual([]);
  });

  it('should keep .env.example present, populated and without obvious real secrets', () => {
    const envExamplePath = resolve(process.cwd(), '.env.example');
    const envExampleContent = readFileSync(envExamplePath, 'utf8');

    expect(envExampleContent).toContain('APP_NAME=');
    expect(envExampleContent).toContain('NODE_ENV=');
    expect(envExampleContent).toContain('DATABASE_HOST=');
    expect(envExampleContent).toContain('PSP_USE_MOCK_SERVER=');
    expect(envExampleContent).toContain('SYNC_PAGE_SIZE=');
    expect(envExampleContent).toContain('OBS_STRUCTURED_LOGGING=');
    expect(envExampleContent).toContain('CACHE_ENABLED=');
    expect(envExampleContent).toContain('OUTBOX_DISPATCHER_ENABLED=');

    expect(envExampleContent).toContain('DATABASE_PASSWORD=\n');
    expect(envExampleContent).toContain('PAGARME_API_KEY=\n');
    expect(envExampleContent).toContain('MERCADOPAGO_ACCESS_TOKEN=\n');
    expect(envExampleContent).toContain('SECURITY_HASH_SALT=\n');
    expect(envExampleContent).not.toContain('sk_live_');
    expect(envExampleContent).not.toContain('BEGIN PRIVATE KEY');
  });
});
