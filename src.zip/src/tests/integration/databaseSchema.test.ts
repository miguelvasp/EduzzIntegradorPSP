import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import { describe, expect, it } from 'vitest';

function readProjectFile(relativePath: string): string {
  return readFileSync(resolve(process.cwd(), relativePath), 'utf8');
}

describe('database schema', () => {
  describe('versioned scripts', () => {
    it('should keep the versioned SQL scripts in the repository', () => {
      const expectedScripts = [
        'scripts/V001__create_database.sql',
        'scripts/V002__create_core_transaction_tables.sql',
        'scripts/V003__create_operational_tables.sql',
        'scripts/V004__create_indexes.sql',
      ];

      for (const relativePath of expectedScripts) {
        expect(existsSync(resolve(process.cwd(), relativePath))).toBe(true);
      }
    });

    it('should keep each script responsible for the correct migration step', () => {
      const createDatabase = readProjectFile('scripts/V001__create_database.sql');
      const createCoreTables = readProjectFile('scripts/V002__create_core_transaction_tables.sql');
      const createOperationalTables = readProjectFile('scripts/V003__create_operational_tables.sql');
      const createIndexes = readProjectFile('scripts/V004__create_indexes.sql');

      expect(createDatabase).toContain('CREATE DATABASE EduzzMultiPsp;');
      expect(createDatabase).not.toContain('USE EduzzMultiPsp;');
      expect(createDatabase).not.toContain('CREATE TABLE');

      expect(createCoreTables).toContain('USE EduzzMultiPsp;');
      expect(createCoreTables).toContain('CREATE TABLE dbo.payers');
      expect(createCoreTables).toContain('CREATE TABLE dbo.transactions');
      expect(createCoreTables).toContain('CREATE TABLE dbo.transaction_payer_snapshots');
      expect(createCoreTables).toContain('CREATE TABLE dbo.installments');
      expect(createCoreTables).not.toContain('CREATE TABLE dbo.sync_runs');
      expect(createCoreTables).not.toContain('CREATE NONCLUSTERED INDEX');

      expect(createOperationalTables).toContain('USE EduzzMultiPsp;');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.sync_runs');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.sync_checkpoints');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.idempotency_registry');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.transaction_status_history');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.transaction_events');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.transaction_integration_evidences');
      expect(createOperationalTables).not.toContain('CREATE TABLE dbo.transactions');
      expect(createOperationalTables).not.toContain('CREATE NONCLUSTERED INDEX');

      expect(createIndexes).toContain('USE EduzzMultiPsp;');
      expect(createIndexes).toContain('CREATE UNIQUE NONCLUSTERED INDEX');
      expect(createIndexes).toContain('CREATE NONCLUSTERED INDEX');
      expect(createIndexes).not.toContain('CREATE TABLE dbo.');
    });
  });

  describe('schema structure', () => {
    it('should define the expected core and operational tables', () => {
      const createCoreTables = readProjectFile('scripts/V002__create_core_transaction_tables.sql');
      const createOperationalTables = readProjectFile('scripts/V003__create_operational_tables.sql');

      expect(createCoreTables).toContain('CREATE TABLE dbo.payers');
      expect(createCoreTables).toContain('CREATE TABLE dbo.transactions');
      expect(createCoreTables).toContain('CREATE TABLE dbo.transaction_payer_snapshots');
      expect(createCoreTables).toContain('CREATE TABLE dbo.installments');

      expect(createOperationalTables).toContain('CREATE TABLE dbo.sync_runs');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.sync_checkpoints');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.idempotency_registry');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.transaction_status_history');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.transaction_events');
      expect(createOperationalTables).toContain('CREATE TABLE dbo.transaction_integration_evidences');
    });

    it('should define the main unique constraints, foreign keys and checks', () => {
      const createCoreTables = readProjectFile('scripts/V002__create_core_transaction_tables.sql');
      const createOperationalTables = readProjectFile('scripts/V003__create_operational_tables.sql');

      expect(createCoreTables).toContain('CONSTRAINT UQ_transactions_psp_external_id UNIQUE (psp, external_id)');
      expect(createCoreTables).toContain(
        'CONSTRAINT UQ_installments_transaction_id_installment_number UNIQUE (transaction_id, installment_number)',
      );
      expect(createCoreTables).toContain(
        'CONSTRAINT FK_transactions_payer_id FOREIGN KEY (payer_id) REFERENCES dbo.payers(id)',
      );
      expect(createCoreTables).toContain(
        'CONSTRAINT FK_transaction_payer_snapshots_transaction_id FOREIGN KEY (transaction_id) REFERENCES dbo.transactions(id)',
      );
      expect(createCoreTables).toContain(
        'CONSTRAINT FK_transaction_payer_snapshots_payer_id FOREIGN KEY (payer_id) REFERENCES dbo.payers(id)',
      );
      expect(createCoreTables).toContain(
        'CONSTRAINT FK_installments_transaction_id FOREIGN KEY (transaction_id) REFERENCES dbo.transactions(id)',
      );
      expect(createCoreTables).toContain(
        "CONSTRAINT CK_transactions_status CHECK (status IN ('pending', 'paid', 'canceled', 'refunded', 'failed', 'disputed', 'partially_refunded', 'unknown'))",
      );
      expect(createCoreTables).toContain("CONSTRAINT CK_transactions_payment_method CHECK (payment_method = 'credit_card')");
      expect(createCoreTables).toContain(
        "CONSTRAINT CK_installments_status CHECK (status IN ('pending', 'paid', 'canceled', 'failed', 'refunded', 'scheduled', 'unknown'))",
      );

      expect(createOperationalTables).toContain(
        'CONSTRAINT FK_sync_checkpoints_last_successful_run_id FOREIGN KEY (last_successful_run_id) REFERENCES dbo.sync_runs(id)',
      );
      expect(createOperationalTables).toContain(
        'CONSTRAINT FK_transaction_status_history_transaction_id FOREIGN KEY (transaction_id) REFERENCES dbo.transactions(id)',
      );
      expect(createOperationalTables).toContain(
        'CONSTRAINT FK_transaction_status_history_sync_run_id FOREIGN KEY (sync_run_id) REFERENCES dbo.sync_runs(id)',
      );
      expect(createOperationalTables).toContain(
        'CONSTRAINT FK_transaction_events_transaction_id FOREIGN KEY (transaction_id) REFERENCES dbo.transactions(id)',
      );
      expect(createOperationalTables).toContain(
        'CONSTRAINT FK_transaction_integration_evidences_transaction_id FOREIGN KEY (transaction_id) REFERENCES dbo.transactions(id)',
      );
      expect(createOperationalTables).toContain('CONSTRAINT UQ_idempotency_registry_scope_idempotency_key UNIQUE');
      expect(createOperationalTables).toContain('CONSTRAINT CK_transaction_events_payload_json_is_json CHECK');
      expect(createOperationalTables).toContain('CONSTRAINT CK_transaction_integration_evidences_payload_json_is_json CHECK');
    });

    it('should protect payer data by persisting only document_hash instead of plain document text', () => {
      const createCoreTables = readProjectFile('scripts/V002__create_core_transaction_tables.sql');

      expect(createCoreTables).toContain('document_hash CHAR(64) NOT NULL');
      expect(createCoreTables).not.toMatch(/\bdocument\s+NVARCHAR/i);
      expect(createCoreTables).not.toMatch(/\bdocument_number\b/i);
      expect(createCoreTables).not.toMatch(/\bdocument_value\b/i);
    });

    it('should stay aligned with the canonical relational model instead of external PSP payload structure', () => {
      const createCoreTables = readProjectFile('scripts/V002__create_core_transaction_tables.sql');
      const createOperationalTables = readProjectFile('scripts/V003__create_operational_tables.sql');
      const combinedScripts = `${createCoreTables}\n${createOperationalTables}`;

      expect(combinedScripts).not.toMatch(/\bcharges\b/i);
      expect(combinedScripts).not.toMatch(/\blast_transaction\b/i);
      expect(combinedScripts).not.toMatch(/\bpayment_type_id\b/i);
      expect(combinedScripts).not.toMatch(/\bstatus_detail\b/i);
      expect(combinedScripts).not.toMatch(/\bfee_details\b/i);
      expect(combinedScripts).not.toMatch(/\bcustomer\.type\b/i);
      expect(combinedScripts).not.toMatch(/\borders\b/i);
    });
  });

  describe('indexes and persistence structure', () => {
    it('should define the main indexes for canonical transactions, installments and evidences', () => {
      const createIndexes = readProjectFile('scripts/V004__create_indexes.sql');

      expect(createIndexes).toContain('CREATE UNIQUE NONCLUSTERED INDEX UX_payers_psp_external_id');
      expect(createIndexes).toContain('CREATE NONCLUSTERED INDEX IX_transactions_psp_status_psp_created_at');
      expect(createIndexes).toContain('CREATE NONCLUSTERED INDEX IX_transactions_psp_created_at');
      expect(createIndexes).toContain('CREATE NONCLUSTERED INDEX IX_transactions_status_psp_created_at');
      expect(createIndexes).toContain('CREATE UNIQUE NONCLUSTERED INDEX UX_transaction_payer_snapshots_transaction_id_snapshot_version');
      expect(createIndexes).toContain('CREATE NONCLUSTERED INDEX IX_installments_transaction_id_status');
      expect(createIndexes).toContain('CREATE NONCLUSTERED INDEX IX_sync_runs_source_name_started_at');
      expect(createIndexes).toContain('CREATE NONCLUSTERED INDEX IX_transaction_events_transaction_id_occurred_at');
      expect(createIndexes).toContain('CREATE NONCLUSTERED INDEX IX_transaction_integration_evidences_psp_external_id_captured_at');
    });

    it('should keep the minimum persistence directories present', () => {
      const expectedPaths = [
        'src/modules/transactions/infrastructure/persistence/migrations',
        'src/modules/transactions/infrastructure/persistence/schemas',
        'src/modules/transactions/infrastructure/persistence/repositories',
      ];

      for (const relativePath of expectedPaths) {
        expect(existsSync(resolve(process.cwd(), relativePath))).toBe(true);
      }
    });
  });

  describe('documentation coherence', () => {
    it('should keep the database documentation artifacts present', () => {
      expect(existsSync(resolve(process.cwd(), 'docs/architecture/data-model.md'))).toBe(true);
      expect(existsSync(resolve(process.cwd(), 'docs/architecture/database-schema.md'))).toBe(true);
    });

    it('should keep README aligned with database scripts and technical docs', () => {
      const readme = readProjectFile('README.md');

      expect(readme).toContain('V001__create_database.sql');
      expect(readme).toContain('V002__create_core_transaction_tables.sql');
      expect(readme).toContain('V003__create_operational_tables.sql');
      expect(readme).toContain('V004__create_indexes.sql');
      expect(readme).toContain('docs/architecture/data-model.md');
      expect(readme).toContain('docs/architecture/database-schema.md');
    });

    it('should keep the technical docs aligned with the approved schema artifacts', () => {
      const dataModel = readProjectFile('docs/architecture/data-model.md');
      const databaseSchema = readProjectFile('docs/architecture/database-schema.md');

      expect(dataModel).toContain('`transactions` garante unicidade canonica por `(psp, external_id)`');
      expect(dataModel).toContain('`transaction_payer_snapshots`');
      expect(dataModel).toContain('`transaction_integration_evidences`');

      expect(databaseSchema).toContain('`transactions` e unica por `(psp, external_id)`');
      expect(databaseSchema).toContain('`installments` e unica por `(transaction_id, installment_number)`');
      expect(databaseSchema).toContain('o documento do pagador nao e persistido em texto puro, apenas em `document_hash`');
      expect(databaseSchema).toContain('`transaction_integration_evidences.payload_json` guarda JSON bruto do PSP');
    });
  });
});
