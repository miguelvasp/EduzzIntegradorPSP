import { describe, expect, it, vi } from 'vitest';

describe('configuration bootstrap', () => {
    it('should initialize the configuration loader with valid environment values', async () => {
        vi.resetModules();

        const originalEnvironment = { ...process.env };

        process.env = {
            ...originalEnvironment,
            APP_NAME: 'bootstrap-app',
            NODE_ENV: 'test',
            HOST: '127.0.0.1',
            PORT: '3456',
            LOG_LEVEL: 'warn',
            DOCS_ENABLED: 'false',
            DATABASE_HOST: 'localhost',
            DATABASE_PORT: '1433',
            DATABASE_NAME: 'eduzz_integrador_psp',
            DATABASE_USER: 'sa',
            DATABASE_CONNECTION_TIMEOUT_MS: '5000',
            DATABASE_POOL_MIN: '1',
            DATABASE_POOL_MAX: '10',
            PSP_USE_MOCK_SERVER: 'true',
            PSP_TIMEOUT_MS: '10000',
            PSP_RETRY_ATTEMPTS: '2',
            PAGARME_BASE_URL: 'http://localhost:4010/pagarme',
            MERCADOPAGO_BASE_URL: 'http://localhost:4020/mercadopago',
            SYNC_PAGE_SIZE: '20',
            SYNC_MAX_PAGE_SIZE: '100',
            SYNC_INCREMENTAL_WINDOW_MINUTES: '60',
            SYNC_SAFETY_OVERLAP_MINUTES: '5',
            SECURITY_MASK_SENSITIVE_DATA: 'true',
            SECURITY_REDACT_SECRETS_IN_LOGS: 'true',
            OBS_STRUCTURED_LOGGING: 'true',
            OBS_METRICS_ENABLED: 'false',
            OBS_REQUEST_CORRELATION_ENABLED: 'true',
            CACHE_ENABLED: 'false',
            CACHE_TTL_SECONDS: '60',
            OUTBOX_DISPATCHER_ENABLED: 'false',
            OUTBOX_BATCH_SIZE: '50',
            OUTBOX_POLL_INTERVAL_MS: '5000',
            OUTBOX_RETRY_LIMIT: '3',
        };

        try {
            const { config } = await import('../../app/config/env');

            expect(config.app).toMatchObject({
                name: 'bootstrap-app',
                env: 'test',
                host: '127.0.0.1',
                port: 3456,
                docsEnabled: false,
                isTest: true,
            });
        } finally {
            process.env = originalEnvironment;
            vi.resetModules();
        }
    });

    it('should bootstrap the server with the central configuration when it is valid', async () => {
        vi.resetModules();

        const listenSpy = vi.fn().mockResolvedValue(undefined);
        const infoSpy = vi.fn();
        const buildContainerSpy = vi.fn();
        const createServerSpy = vi.fn(() => ({
            listen: listenSpy,
            log: {
                info: infoSpy,
            },
        }));

        vi.doMock('../../app/server/createServer', () => ({
            createServer: createServerSpy,
        }));
        vi.doMock('../../app/container/index.js', () => ({
            buildContainer: buildContainerSpy,
        }));
        vi.doMock('../../app/config/env.js', () => ({
            config: {
                app: {
                    host: '0.0.0.0',
                    port: 3000,
                },
            },
        }));

        try {
            await import('../../app/server/index');

            await Promise.resolve();
            await Promise.resolve();

            expect(listenSpy).toHaveBeenCalledWith({
                host: '0.0.0.0',
                port: 3000,
            });

            expect(buildContainerSpy).toHaveBeenCalledTimes(1);
            expect(createServerSpy).toHaveBeenCalledTimes(1);
            expect(infoSpy).toHaveBeenCalledWith('Server running at http://0.0.0.0:3000');
        } finally {
            vi.resetModules();
            vi.doUnmock('../../app/server/createServer');
            vi.doUnmock('../../app/container/index.js');
            vi.doUnmock('../../app/config/env.js');
        }
    });

    it('should fail bootstrap in a controlled way when configuration is invalid', async () => {
        vi.resetModules();

        const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => undefined);
        const processExitSpy = vi
            .spyOn(process, 'exit')
            .mockImplementation((() => undefined) as never);
        const createServerSpy = vi.fn();
        const buildContainerSpy = vi.fn();

        vi.doMock('../../app/server/createServer', () => ({
            createServer: createServerSpy,
        }));
        vi.doMock('../../app/container/index.js', () => ({
            buildContainer: buildContainerSpy,
        }));
        vi.doMock('../../app/config/env.js', () => {
            throw new Error(
                'Invalid environment configuration: PORT: Too small: expected number to be >=1',
            );
        });

        try {
            await import('../../app/server/index');

            await Promise.resolve();
            await Promise.resolve();

            expect(consoleErrorSpy).toHaveBeenCalledWith(
                'Failed to start application',
                expect.objectContaining({
                    message: 'Invalid environment configuration: PORT: Too small: expected number to be >=1',
                }),
            );

            expect(processExitSpy).toHaveBeenCalledWith(1);
            expect(buildContainerSpy).not.toHaveBeenCalled();
            expect(createServerSpy).not.toHaveBeenCalled();
        } finally {
            consoleErrorSpy.mockRestore();
            processExitSpy.mockRestore();
            vi.resetModules();
            vi.doUnmock('../../app/server/createServer');
            vi.doUnmock('../../app/container/index.js');
            vi.doUnmock('../../app/config/env.js');
        }
    });
});