IF DB_ID(N'EduzzMultiPsp') IS NULL
BEGIN
    CREATE DATABASE EduzzMultiPsp;
END;
GO